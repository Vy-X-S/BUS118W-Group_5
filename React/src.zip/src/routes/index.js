// import HomePage from "../page/HomePage";
// import ProductPage from "../page/ProductPage";
// import AboutPage from "../page/AboutPage";

// const publicRoutes = [
//   {path: "/", component: HomePage},
//   {path: "/product",component: ProductPage},
//   {path: "/about", component: AboutPage}
// ]

// export {publicRoutes}