// import { memo } from "react";
// import { Redirect, Route } from "react-router-dom";

// const Middleware = memo(({ component: Component, layout: Layout, ...rest }) => (
//   <Route
//     {...rest}
//     render={(props) => {
//       return (
//         <Layout>
//           <Component {...props} />
//         </Layout>
//       );
//     }}
//   />
// ));
